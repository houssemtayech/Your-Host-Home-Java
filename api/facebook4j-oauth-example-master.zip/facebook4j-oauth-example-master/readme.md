I imitated almost the following:  
[https://github.com/yusuke/sign-in-with-twitter](https://github.com/yusuke/sign-in-with-twitter)